Vans = KD2DRI, KC3EMR
Balloon = W3EAX-11, KB3ZZI


Flight Info
-------------------------------
Max altitude = 90,059ft
Time to Burst = Launch + 86min